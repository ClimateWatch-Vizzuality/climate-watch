import { createAction } from 'redux-actions';

const myModuleAction = createAction('myModuleAction');

export default {
  myModuleAction
};
