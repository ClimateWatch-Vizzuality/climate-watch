const countrySelectFilter = (state, { payload }) => ({ ...state, query: payload });

export default {
  countrySelectFilter
};
