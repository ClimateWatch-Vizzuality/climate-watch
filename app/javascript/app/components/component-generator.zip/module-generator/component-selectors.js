import { createSelector } from 'reselect';

export const mySelector = createSelector(
  state => state
);

export default {
  mySelector
};
