import { createElement } from 'react';
import Proptypes from 'prop-types';
import { connect } from 'react-redux';

import Component from './component-component';
import actions from './component-actions';
import { mySelector } from './component-selectors';

export { default as component } from './component-component';
export { default as reducers } from './component-reducers';
export { default as styles } from './component-styles';
export { default as actions } from './component-actions';

const mapStateToProps = (state) => {
  return {
    myProp: mySelector(state)
  };
};

const ComponentContainer = (props) => {
  return createElement(Component, {
    ...props,
    myProp: 'And I am the prop'
  });
};

ComponentContainer.propTypes = {};

export default connect(mapStateToProps, actions)(ComponentContainer);
